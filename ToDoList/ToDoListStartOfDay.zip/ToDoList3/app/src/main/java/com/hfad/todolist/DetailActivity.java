package com.hfad.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.app.Activity;
import android.os.Bundle;
public class DetailActivity extends Activity {
    public static final String EXTRA_TODO_ID = "id";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        TodoDetailFragment workoutDetailFragment = (TodoDetailFragment)
                getFragmentManager().findFragmentById(R.id.detail_frag);
        int workoutId = (int) getIntent().getExtras().get(EXTRA_TODO_ID);
        workoutDetailFragment.setTodoID(workoutId);
    }
}