package com.hfad.todolist;

import android.os.Bundle;

import android.app.Fragment;

import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class TodoDetailFragment extends Fragment {

    private long todoID;


    @Override
    public void onStart() {
        super.onStart();
        View view = getView();
        if (view != null) {
            TextView title = (TextView) view.findViewById(R.id.textTitle);
            Todo workout = Todo.Todos[(int) todoID];
            title.setText(workout.getName());
            TextView description = (TextView) view.findViewById(R.id.textDescription);
            description.setText(workout.getDescription());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            todoID = savedInstanceState.getLong("todoID");
        }
        return inflater.inflate(R.layout.fragment_todo_detail, container, false);
    }

    public void setTodoID(long id) {
        this.todoID = id;
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putLong("todoID", todoID);
    }
}